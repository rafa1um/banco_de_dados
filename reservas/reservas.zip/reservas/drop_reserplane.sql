DROP TABLE res_trch;
DROP TABLE reserva;
DROP TABLE horario;
DROP TABLE trecho;
DROP TABLE voo;
DROP TABLE aeroporto;
DROP TABLE cidade;
DROP TABLE tipo_aeronave_assento;
DROP TABLE tipo_aeronave;
DROP TABLE assento;


